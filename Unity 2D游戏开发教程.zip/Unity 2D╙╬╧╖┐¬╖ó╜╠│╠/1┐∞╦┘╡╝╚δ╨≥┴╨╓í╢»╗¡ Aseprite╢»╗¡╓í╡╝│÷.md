### 如何在Unity中快速导入序列帧动画 Aseprite动画帧导出

![](C:\Users\goodboy\Pictures\Screenshots\QQ图片20241216140958.png

![image-20241216141619795](Images.assets/image-20241216141619795.png)



再点击 Sprite Editor 按钮

![image-20241216141938777](Images.assets/image-20241216141938777.png)



![image-20241216142627652](Images.assets/image-20241216142627652.png)

![image-20241216144356287](Images.assets/image-20241216144356287.png)